from pyparsing import *
from os import listdir
from os.path import isfile, join


class Enum_parser:
    def read_files(self):
        files = [f for f in listdir("enums") if isfile(join("enums", f))]
        enums = {}
        for file in files:
            file = open(join('enums',file), 'r', encoding='utf-8')
            enum_text = file.read()
            enums.update(self.parse(enum_text))

        return enums

    def parse(self, text):

        # syntax we don't want to see in the final parse tree
        _lcurl = Suppress('{')
        _rcurl = Suppress('}')
        _equal = Suppress('=')
        _comma = Suppress(',')
        _enum = Suppress('enum')

        identifier = Word(alphas,alphanums+'_')
        integer = Word(nums)

        enumValue = Group(identifier('name') + Optional(_equal + integer('value')) + Optional(_equal + identifier('name')))
        enumList = Group(enumValue + ZeroOrMore(_comma + enumValue))
        enum =  enumList('list')

        enum.ignore(cppStyleComment)

        enums = {}

        for item,start,stop in enum.scanString(text):
            id = 0
            for entry in item.list:
                if entry.value != '':
                    id = int(entry.value)
                #print('%s = %d' % (entry.name.upper(),id))
                enums[id] = entry.name.upper()
                id += 1

        return enums

    def get_names(self):
        return self.read_files()