"""fast, simple packet creation and parsing."""


__author__ = 'Dug Song'
__author_email__ = 'dugsong@monkey.org'
__license__ = 'BSD'
__url__ = 'http://dpkt.googlecode.com/'
__version__ = '1.8.6.2'

from .dpkt import *


from . import ethernet
from . import ip
from . import pcap
from . import rx
from . import tcp


