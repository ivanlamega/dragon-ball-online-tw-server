
unsigned long GenerateAndSaveRandomSeed();
