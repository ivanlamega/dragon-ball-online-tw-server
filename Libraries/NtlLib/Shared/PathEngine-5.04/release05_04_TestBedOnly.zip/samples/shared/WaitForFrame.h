
bool WaitForFrame();
