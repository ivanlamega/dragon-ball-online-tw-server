
#include "i_pathengine.h"
class iTestBed;
class cResources;
class cGameState;
class cGameObject;
extern iPathEngine* gPathEngine;
extern iTestBed* gTestBed;
extern cResources* gResources;
extern cGameState* gGameState;
extern cGameObject* gCurrentObject;
