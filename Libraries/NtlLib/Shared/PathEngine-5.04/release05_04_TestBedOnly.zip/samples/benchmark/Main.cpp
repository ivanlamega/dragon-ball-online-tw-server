
#include "entrypoint.h"
#include <time.h>
#include <sstream>
#include <vector>

void FindPaths(iMesh* mesh, iShape* shape, const std::vector<cPosition>& points)
{
    size_t i;
    for(i = 0; i < points.size(); i++)
    {
        size_t j;
        for(j = i + 1; j < points.size(); j++)
        {
            iPath* path = mesh->findShortestPath(shape, 0, points[i], points[j]);
            delete path;
        }
    }
}

void GetPathStats(iMesh* mesh, iShape* shape,
                    const std::vector<cPosition>& points,
                    long& totalPaths, long& totalPoints,
                    long& numberFailed)
{
    totalPaths = 0;
    totalPoints = 0;
    numberFailed = 0;
    size_t i;
    for(i = 0; i < points.size(); i++)
    {
        size_t j;
        for(j = i + 1; j < points.size(); j++)
        {
            iPath* path = mesh->findShortestPath(shape, 0, points[i], points[j]);
            if(path)
            {
                totalPoints += path->size();
                delete path;
            }
            else
            {
                numberFailed++;
            }
            totalPaths++;
        }
    }
}

iPath* RandomPath(iMesh* mesh, iShape* shape, const std::vector<cPosition>& points)
{
    long i = (rand() % points.size());
    long j = (rand() % (points.size() - 1));
    if(j == i)
        j++;
    return mesh->findShortestPath(shape, 0, points[i], points[j]);
}

void runBenchmark(iPathEngine* pathengine, iTestBed* testbed,
                  const std::string& meshName,
                  const char** collisionPreprocessAttributes,
                  const char** loadOptions
                  )
{
    {
        std::string message = "generating benchmark for '" + meshName + "'";
        testbed->setColour("orange");
        testbed->printTextLine(10, message.c_str());
        testbed->update();
    }

    iMesh* mesh;
    iShape* shape;
    clock_t start, finish;
    double  duration;

    std::vector<std::string> text;

    {
        char* buffer;
        unsigned long size;

        std::string meshPath = "..\\resource\\meshes\\" + meshName + ".tok";
        buffer = testbed->loadBinary(meshPath.c_str(), size);

        start = clock();

        mesh = pathengine->loadMeshFromBuffer("tok", buffer, size, 0);

        finish = clock();

        duration = static_cast<double>(finish - start) / CLOCKS_PER_SEC;
        std::ostringstream os;
        os << "loading mesh = " << duration << " seconds";
        text.push_back(os.str());

        testbed->freeBuffer(buffer);
    }
    {
        long array[]=
        {
            -20, 20,
            20, 20,
            20, -20,
            -20, -20,
        };
        shape = pathengine->newShape(sizeof(array)/sizeof(*array)/2, array);
    }

    testbed->setMesh(mesh);
    testbed->zoomExtents();

    {
        start = clock();
        mesh->generateCollisionPreprocessFor(shape, collisionPreprocessAttributes);
        mesh->generatePathfindPreprocessFor(shape, 0);
        finish = clock();

        duration = static_cast<double>(finish - start) / CLOCKS_PER_SEC;
        std::ostringstream os;
        os << "generating preprocess = " << duration << " seconds";
        text.push_back(os.str());
    }

    std::vector<cPosition> points(60);
    {
        size_t i = 0;
        while(i < points.size())
        {
            cPosition randomPoint = mesh->generateRandomPosition();
            if(randomPoint.cell != -1 && !mesh->testPointCollision(shape, 0, randomPoint))
            {
                points[i++] = randomPoint;
            }
        }
    }

    {
        start = clock();
        FindPaths(mesh, shape, points);
        finish = clock();

        duration = static_cast<double>(finish - start) / CLOCKS_PER_SEC;

        long totalPaths, totalPoints, numberFailed;
        GetPathStats(mesh, shape, points, totalPaths, totalPoints, numberFailed);

        {
            std::ostringstream os;
            os << " failed paths = " << numberFailed;
            text.push_back(os.str());
        }

        long successfulPaths = totalPaths - numberFailed;
        if(successfulPaths)
        {
            std::ostringstream os;
            os << " successful paths = " << successfulPaths;
            os << ", average points = " << static_cast<double>(totalPoints) / successfulPaths;
            text.push_back(os.str());
        }
        {
            std::ostringstream os;
            os << " total time = " << duration << ", average time = " << duration / totalPaths;
            text.push_back(os.str());
        }
    }

    text.push_back("benchmark for '" + meshName + "'");

    while(!testbed->getKeyState("_SPACE"))
    {
        testbed->setColourRGB(0.0f,0.0f,0.85f);
        testbed->drawMesh();
        testbed->setColour("blue");
        testbed->drawMeshEdges();
        testbed->setColour("white");
        testbed->drawBurntInObstacles();
        testbed->printTextLine(10, "press space for next benchmark, or to finish");
        {
            size_t i = text.size();
            while(i > 0)
            {
                i--;
                testbed->printTextLine(10, text[i].c_str());
            }
        }

        testbed->setColour("green");
        {
            long i;
            for(i = 0; i < 20; i++)
            {
                iPath* path = RandomPath(mesh, shape, points);
                testbed->drawPath(path);
                delete path;
            }
        }

        testbed->update();
    }

    testbed->releaseMesh();
    pathengine->deleteAllObjects();
}

void demo(iPathEngine* pathengine, iTestBed* testbed)
{
    runBenchmark(pathengine, testbed, "mesh1", 0, 0);
    runBenchmark(pathengine, testbed, "flatshead_dungeon", 0, 0);
    {
        const char* attributes[3];
        attributes[0] = "split_with_circumference_below";
        attributes[1] = "2000";
        attributes[2] = 0;
        runBenchmark(pathengine, testbed, "thainesford", attributes, 0);
    }
}
