//**********************************************************************
//
// Copyright (c) 2002-2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

bool MemoryTrackingIsEnabled();
unsigned long GetTotalMemoryAllocated();
unsigned long GetMaximumMemoryAllocated();
void ResetMaximumMemoryAllocated();
