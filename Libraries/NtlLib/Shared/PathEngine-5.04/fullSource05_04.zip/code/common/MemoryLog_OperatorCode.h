//**********************************************************************
//
// Copyright (c) 2002
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

enum eOperatorCode
{
    OC_NEW,
    OC_NEW_ARRAY,
    OC_DELETE,
    OC_DELETE_ARRAY,
    OC_REFERENCE_ADDRESS,
};
