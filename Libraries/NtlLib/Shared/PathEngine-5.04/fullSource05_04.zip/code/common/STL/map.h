//**********************************************************************
//
// Copyright (c) 2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#ifndef REPLACE_STL
#include <map>
#else
#ifndef STL_MAP_INCLUDED
#define STL_MAP_INCLUDED

namespace std
{

not implemented yet

}

#endif
#endif
