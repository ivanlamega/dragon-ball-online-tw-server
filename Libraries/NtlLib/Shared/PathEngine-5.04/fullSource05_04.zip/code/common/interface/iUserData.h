//**********************************************************************
//
// Copyright (c) 2006
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#ifndef I_USER_DATA_INCLUDED
#define I_USER_DATA_INCLUDED

class iUserData
{
public:
    virtual ~iUserData() {}
};

#endif
