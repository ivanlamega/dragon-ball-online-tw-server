
#include "common/interface/Assert.h"
#define test(expr) assertR(expr)
#define TEST_MAIN(name) void name()
