//**********************************************************************
//
// Copyright (c) 2005
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#ifndef E_EXPAND_SECTION_TYPE_INCLUDED
#define E_EXPAND_SECTION_TYPE_INCLUDED

enum eExpandSectionType
{
    EST_PARALLEL,
    EST_RADIAL,
};

#endif
