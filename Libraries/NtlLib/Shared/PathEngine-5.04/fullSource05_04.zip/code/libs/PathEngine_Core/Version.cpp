
#include "interface/Version.h"

const
char* VersionTimeString()
{
    return "2006-09-13 16:01";
}
long
MajorRelease()
{
    return 5;
}
long
MinorRelease()
{
    return 4;
}
long
InternalRelease()
{
    return 0;
}

