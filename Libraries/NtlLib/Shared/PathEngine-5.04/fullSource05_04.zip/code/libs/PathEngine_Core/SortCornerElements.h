//**********************************************************************
//
// Copyright (c) 2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "common/STL/vector.h"

class cCircuitElement;

void
SortCornerElements(std::vector<const cCircuitElement*>& elements);
