//**********************************************************************
//
// Copyright (c) 2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

unsigned long
HighestCommonFactor(unsigned long u, unsigned long v);

long
HighestCommonFactor(long u, long v);
