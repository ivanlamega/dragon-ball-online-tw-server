//**********************************************************************
//
// Copyright (c) 2002
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

class cMeshCut;
template <class T> class cHandleList;
typedef cHandleList<cMeshCut> tMeshCutSequence;
typedef cHandleList<tMeshCutSequence> tMeshCircuits;
