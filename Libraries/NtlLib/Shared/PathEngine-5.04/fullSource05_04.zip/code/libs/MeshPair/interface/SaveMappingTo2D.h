//**********************************************************************
//
// Copyright (c) 2005
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "libs/Mesh2D/interface/tMesh_Header.h"

class iXMLOutputStream;

void
SaveMappingTo2D(long verticesIn3D, tMesh& mesh, iXMLOutputStream& os);
