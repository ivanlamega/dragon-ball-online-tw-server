

#include "libs/Geometry/interface/tPoint3_Header.h"
#include "libs/Geometry/interface/Point3.h"
#include "platform_common/PointTraits.h"
typedef tPoint3::tMultiplier tMultiplier;
