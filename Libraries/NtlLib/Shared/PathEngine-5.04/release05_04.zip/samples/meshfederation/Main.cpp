
#include "EntryPoint.h"
#include "FileOutputStream.h"
#include "WaitForFrame.h"
#include <sstream>
#include <vector>
#include <math.h>

iTestBed* gTestBed;

void
ControlCamera(float& heading, float& elevation)
{
    if(!gTestBed->getRightMouseState())
    {
        return;
    }
    long dx, dy;
    gTestBed->getMouseScreenDelta(dx, dy);
    heading += dx * 0.016f;
    heading = fmod(heading, 6.2856f);
    elevation += dy * 0.016f;
    if(elevation > 1.5f)
    {
        elevation = 1.5f;
    }
    else
    if(elevation < -0.05f)
    {
        elevation = -0.05f;
    }
}

class cSaveTileMeshesCallBack : public iMeshFederationTileGeneratedCallBack
{
public:
    void tileGenerated(long tileIndex, iMesh* tileMesh);
};
void
cSaveTileMeshesCallBack::tileGenerated(long tileIndex, iMesh* tileMesh)
{
    std::ostringstream fileName;
    fileName << "..\\resource\\meshes\\federationTile" << tileIndex << ".tok";
    cFileOutputStream fos(fileName.str().c_str());
    tileMesh->saveGround("tok", true, &fos);
    delete tileMesh;
    gTestBed->printTextLine(5, fileName.str().c_str());
    gTestBed->printTextLine(5, "finished generating content tile:");
    gTestBed->printTextLine(5, "Generating Federation Tile Meshes");
    gTestBed->update();
}

static iMesh*
LoadTileMesh(iTestBed* testBed, iPathEngine* pathEngine, long tileIndex)
{
    std::ostringstream fileName;
    fileName << "..\\resource\\meshes\\federationTile" << tileIndex << ".tok";
    char* buffer;
    unsigned long size;
    buffer = testBed->loadBinary(fileName.str().c_str(), size);
    if(!buffer)
    {
        return 0;
    }
    iMesh* result = pathEngine->loadMeshFromBuffer("tok", buffer, size, 0);
    testBed->freeBuffer(buffer);
    return result;
}

static void
PositionInFederationNear3DPoint(
        const long* point,
        long horizontalRange, long verticalRange,
        const iMeshFederation* federation,
        iMesh** tileMeshes,
        long& tileIndex, cPosition& positionInTile
        )
{
    tileIndex = federation->tileForQuery(point[0], point[1]);
    if(tileMeshes[tileIndex] == 0)
    {
        positionInTile.cell = -1;
        return;
    }
    long tileCentreX, tileCentreY;
    federation->getTileCentre(tileIndex, tileCentreX, tileCentreY);
    long tileLocalPoint[3];
    tileLocalPoint[0] = point[0] - tileCentreX;
    tileLocalPoint[1] = point[1] - tileCentreY;
    tileLocalPoint[2] = point[2];
    positionInTile = tileMeshes[tileIndex]->positionNear3DPoint(tileLocalPoint, horizontalRange, verticalRange);
}

// this stuff would usually happen at content generation time
// (and could be skipped after the first time the demo is run, as long as the world mesh is not changed)
void
BuildFederation(
        iPathEngine* pathEngine, iTestBed* testBed,
        iMesh* worldMesh,
        long tileSize, long overlap
        )
{
    cSaveTileMeshesCallBack callback;

    iMeshFederation* federation;
    federation = pathEngine->buildMeshFederation_FromWorldMesh(
            worldMesh,
            tileSize, overlap,
            callback
            );

    std::ostringstream fileName;
    fileName << "..\\resource\\federation.tok";
    cFileOutputStream fos(fileName.str().c_str());
    federation->save("tok", &fos);
    delete federation;
}

void
demo(iPathEngine* pathEngine, iTestBed* testBed)
{
    const char* worldMeshName = "thainesford_town";
    const long tileSize = 8000;
    const long overlap = 2000;
    const long agentSize = 20;
    const long agentHeight = agentSize * 6;
    const float agentSpeed = static_cast<float>(agentSize) * 0.75f;
    const float cameraDistance = static_cast<float>(agentSize) * 350.f;
    const long resolveRange = agentSize * 3;

    gTestBed = testBed;

    iMesh* worldMesh;
    {
        char* buffer;
        unsigned long size;
        std::string meshPath = "..\\resource\\meshes\\";
        meshPath.append(worldMeshName);
        meshPath.append(".tok");
        buffer = testBed->loadBinary(meshPath.c_str(), size);
        worldMesh = pathEngine->loadMeshFromBuffer("tok", buffer, size, 0);
        testBed->freeBuffer(buffer);
    }

    BuildFederation(pathEngine, testBed, worldMesh, tileSize, overlap);

    iMeshFederation* federation;
    {
        char* buffer;
        unsigned long size;
        buffer = testBed->loadBinary("..\\resource\\federation.tok", size);
        federation = pathEngine->loadFederation("tok", buffer, size);
        testBed->freeBuffer(buffer);
    }

    iShape* agentShape;
    {
        long array[]=
        {
            -agentSize, agentSize,
            agentSize, agentSize,
            agentSize, -agentSize,
            -agentSize, -agentSize,
        };
        agentShape = pathEngine->newShape(sizeof(array)/sizeof(*array)/2, array);
    }

    worldMesh->generateCollisionPreprocessFor(agentShape, 0);

    const char* attributes[3];
    attributes[0] = "split_with_circumference_below";
    attributes[1] = "2000";
    attributes[2] = 0;

    std::vector<iMesh*> tileMeshes(federation->size(), 0);
    std::vector<iCollisionContext*> contexts(federation->size(), 0);
    long i;
    for(i = 0; i != federation->size(); ++i)
    {
        tileMeshes[i] = LoadTileMesh(testBed, pathEngine, i);
        if(tileMeshes[i] == 0)
        {
            continue;
        }

        tileMeshes[i]->generateCollisionPreprocessFor(agentShape, 0);
        tileMeshes[i]->generatePathfindPreprocessFor(agentShape, attributes);

        {
        // set up a collision context for each tile
        // with query bounds that restrict pathfinding to the tile's represented region
        // query bounds act on agent origin, so the region is brought in by agentSize
        // so that the agent's shape does not overlap outside the represented region
            contexts[i] = tileMeshes[i]->newContext();
            long minX, minY, maxX, maxY;
            federation->getRepresentedRegion_Local(i, minX, minY, maxX, maxY);
            assertD(maxX - minX > agentSize * 2); // the tile overlap must be large than agent size
            assertD(maxY - minY > agentSize * 2);
            minX += agentSize;
            minY += agentSize;
            maxX -= agentSize;
            maxY -= agentSize;
            contexts[i]->setQueryBounds(minX, minY, maxX, maxY);
        }

      // display the meshes as they get loaded
      // with handled and represented regions boundaries drawn
      // note that this also generates any rendering preprocess required by the testbed,
      // and therefore helps to avoid pauses when the testbed subsequently switches between tile meshes

        std::ostringstream fileName;
        fileName << "..\\resource\\meshes\\federationTile" << i << ".tok";
        gTestBed->printTextLine(5, fileName.str().c_str());
        gTestBed->printTextLine(5, "finished loading and preprocessing tile:");
        gTestBed->printTextLine(5, "Loading and Preprocessing Tile Meshes");
        testBed->setMesh(tileMeshes[i]);
        testBed->zoomExtents();
        testBed->setColourRGB(0.f, 0.f, 0.85f);
        testBed->drawMesh();
        testBed->setColour("blue");
        testBed->drawMeshEdges();
        testBed->setColour("white");
        testBed->drawBurntInObstacles();
        {
            long minX, minY, maxX, maxY;
            federation->getRepresentedRegion_Local(i, minX, minY, maxX, maxY);
            testBed->setColour("red");
            testBed->drawRangeBounds(minX, minY, maxX, maxY);
            federation->getHandledRegion_Local(i, minX, minY, maxX, maxY);
            testBed->setColour("yellow");
            testBed->drawRangeBounds(minX, minY, maxX, maxY);
        }
        testBed->update();
    }

    iAgent* agent = 0;
    long agentTile = -1;

  // start the agent at a random position, generated on the world mesh
  // the position is then translated onto the relevant federation tile

    {
        cPosition worldPosition;
        do
        {
            worldPosition = worldMesh->generateRandomPosition();
        }
        while(worldMesh->testPointCollision(agentShape, 0, worldPosition));

        long worldPositionXYZ[3];
        worldPositionXYZ[0] = worldPosition.x;
        worldPositionXYZ[1] = worldPosition.y;
        worldPositionXYZ[2] = worldMesh->heightAtPosition(worldPosition);

        cPosition agentStartPosition;
        PositionInFederationNear3DPoint(
                worldPositionXYZ, 50, 50, federation, &tileMeshes[0],
                agentTile, agentStartPosition
                );
        // for positions picked against rendered geometry, this could fail
        // but in this case the position resolution should always succeed
        assertD(agentStartPosition.cell != -1);

        agent = tileMeshes[agentTile]->placeAgent(agentShape, agentStartPosition);
    }

    testBed->setMesh(tileMeshes[agentTile]);

    float cameraHeading = 0.f;
    float cameraElevation = 1.f;

    float agentHeading = 0;
    float agentPrecisionX = 0.f;
    float agentPrecisionY = 0.f;
    iPath* path = 0;
    bool markerSet = false;
    cPosition markerPosition;
    const char* markerColour;

    bool exitFlag = false;
    while(!exitFlag)
    {
        ControlCamera(cameraHeading, cameraElevation);
        testBed->lookAtWithPrecision(
                agent->getPosition(), agentPrecisionX, agentPrecisionY,
                cameraHeading, cameraElevation,
                cameraDistance
                );

        testBed->setColourRGB(0.f, 0.f, 0.85f);
        testBed->drawMesh();
        testBed->setColour("blue");
        testBed->drawMeshEdges();
        testBed->setColour("white");
        testBed->drawBurntInObstacles();

        {
            long minX, minY, maxX, maxY;
            federation->getRepresentedRegion_Local(agentTile, minX, minY, maxX, maxY);
            testBed->setColour("red");
            testBed->drawRangeBounds(minX, minY, maxX, maxY);
            federation->getHandledRegion_Local(agentTile, minX, minY, maxX, maxY);
            testBed->setColour("yellow");
            testBed->drawRangeBounds(minX, minY, maxX, maxY);
        }

        testBed->setColour("orange");
        testBed->drawAgentWithPrecision(agent, agentHeight, agentPrecisionX, agentPrecisionY);
        testBed->setColour("purple");
        testBed->drawAgentHeadingWithPrecision(agent, agentSize * 2, agentHeight, agentHeading, agentPrecisionX, agentPrecisionY);

      // draw path if there is one
        testBed->setColour("green");
        testBed->drawPath(path);

      // draw marker, if set
        if(markerSet)
        {
            testBed->setColour(markerColour);
            testBed->drawPosition(markerPosition, agentSize * 2);
        }

        WaitForFrame();
        testBed->update();

        bool repathRequested = false;

    // receive and process messages for all keys pressed since last frame
        const char* keyPressed;
        while(keyPressed = testBed->receiveKeyMessage())
        {
            if(keyPressed[0] != 'd' || keyPressed[1] != '_')
            {
              // only interested in key down messages for keys with extended key strings, here
                continue;
            }
            if(strcmp("ESCAPE", keyPressed + 2) == 0)
            {
                exitFlag = true;
            }
            else if(strcmp("LMOUSE", keyPressed + 2) == 0)
            {
                repathRequested = true;
            }
        }

        if(repathRequested || (path && path->size() == 1))
        {
          // clear the existing path

            delete path;
            path = 0;
            markerSet = false;

          // and check whether we need to translate to a neighbouring tile

            long worldX, worldY;
            federation->getTileCentre(agentTile, worldX, worldY);
            worldX += agent->getPosition().x;
            worldY += agent->getPosition().y;
            long tileForQuery = federation->tileForQuery(worldX, worldY);
            if(tileForQuery != agentTile)
            {
                cPosition positionOnOverlapped = federation->translatePosition(
                        agentTile, tileMeshes[agentTile],
                        tileForQuery, tileMeshes[tileForQuery],
                        agent->getPosition()
                        );
                assertD(positionOnOverlapped.cell != -1);
                delete agent;
                agentTile = tileForQuery;
                agent = tileMeshes[agentTile]->placeAgent(agentShape, positionOnOverlapped);
                testBed->setMesh(tileMeshes[agentTile]);
                // update camera position,
                // required for the call to positionAtMouse(), below
                testBed->lookAtWithPrecision(
                        agent->getPosition(), agentPrecisionX, agentPrecisionY,
                        cameraHeading, cameraElevation,
                        cameraDistance
                        );
            }
        }

        if(path)
        {
            if(path->size() >= 2)
            {
            // set heading from the vector for the current path section
                cPosition nextTarget = path->position(1);
                cPosition current = agent->getPosition();
                long dx,dy;
                dx = nextTarget.x - current.x;
                dy = nextTarget.y - current.y;
                agentHeading = static_cast<float>(atan2(static_cast<double>(dx), static_cast<double>(dy)));
            }
            agent->advanceAlongPathWithPrecision(path, agentSpeed, 0, agentPrecisionX, agentPrecisionY);
        }

        if(repathRequested)
        {
          // send agent to the position currently under the mouse cursor
          // note that we guaranteed, above, that the agent is in the handled region for agentTile

            cPosition target = testBed->positionAtMouse();
            if(target.cell != -1)
            {
                markerSet = true;
                markerPosition = target;
                cPosition unobstructed = tileMeshes[agentTile]->findClosestUnobstructedPosition(agentShape, 0, target, resolveRange);
                if(unobstructed.cell == -1)
                {
                  // unable to find an unobstructed position within range
                    markerColour = "red";
                }
                else
                {
                    markerColour = "yellow";
                    path = agent->findShortestPathTo(contexts[agentTile], unobstructed);
                }
            }
        }
    }
}
