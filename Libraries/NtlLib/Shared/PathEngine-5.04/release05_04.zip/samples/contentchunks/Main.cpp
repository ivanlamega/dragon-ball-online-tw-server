
#include "entrypoint.h"
#include "FileOutputStream.h"
#include <vector>
#include <string>
#include <sstream>

class cPartitionedTerrain : public iFaceVertexMesh
{
    long _originX, _originY;
    long _squareSize, _squaresAcross;

public:

    cPartitionedTerrain(
            long originX, long originY,
            long squareSize, long squares
            ) :
     _originX(originX),
     _originY(originY),
     _squareSize(squareSize),
     _squaresAcross(squares)
    {
    }

// iFaceVertexMesh interface

    long faces() const
    {
        return _squaresAcross * _squaresAcross * 2;
    }
    long vertices() const
    {
        return (_squaresAcross + 1) * (_squaresAcross + 1);
    }
    long vertexIndex(long face, long vertexInFace) const
    {
        long baseVertex = face / 2 + face / 2 / _squaresAcross;
        if(face & 1)
        {
            switch(vertexInFace)
            {
            default:
//                invalid
            case 0:
                return baseVertex;
            case 1:
                return baseVertex + 1;
            case 2:
                return baseVertex + (_squaresAcross + 1) + 1;
            }
        }
        switch(vertexInFace)
        {
        default:
//            invalid
        case 0:
            return baseVertex;
        case 1:
            return baseVertex + (_squaresAcross + 1) + 1;
        case 2:
            return baseVertex + (_squaresAcross + 1);
        }
    }
    long vertexX(long vertex) const
    {
        return _originX + vertex / (_squaresAcross + 1) * _squareSize;
    }
    long vertexY(long vertex) const
    {
        return _originY + (vertex % (_squaresAcross + 1)) * _squareSize;
    }
    float vertexZ(long vertex) const
    {
        return 0.0f;
    }
    long faceAttribute(long face, long attributeIndex) const
    {
        if(attributeIndex == PE_FaceAttribute_SectionID)
        {
            return 0; // mark all faces as sectionID == 0 (first terrain layer)
        }
        return -1;
    }
};

static iContentChunk*
LoadChunk(iPathEngine* pathEngine, iTestBed* testBed, const char* name)
{
    char* buffer;
    unsigned long bufferSize;
    std::string fileName = "..\\resource\\content\\";
    fileName.append(name);
    fileName.append(".tok");
    buffer = testBed->loadBinary(fileName.c_str(), bufferSize);
    iContentChunk* result = pathEngine->loadContentChunk(buffer, bufferSize);
    testBed->freeBuffer(buffer);
    return result;
}

class cPlacedContentChunk
{
    iContentChunk* _chunk;
    long _rotation;
    long _scale;
    long _x, _y;
    float _z;
    size_t _id;

public:

    cPlacedContentChunk(iContentChunk* chunk, long rotation, long scale, long x, long y, float z, size_t id) :
     _chunk(chunk),
     _rotation(rotation),
     _scale(scale),
     _x(x),
     _y(y),
     _z(z),
     _id(id)
    {
    }

    void instantiate(std::vector<const iFaceVertexMesh*>& groundParts) const;
    void addAnchorsAndShapes(iMesh* addTo) const;
};

void
cPlacedContentChunk::instantiate(std::vector<const iFaceVertexMesh*>& groundParts) const
{
    const iFaceVertexMesh* instantiatedGround = _chunk->instantiate(_rotation, _scale, _x, _y, _z);
    if(instantiatedGround) // this check is required in case content chunks have no ground elements
    {
        groundParts.push_back(instantiatedGround);
    }
}

void
cPlacedContentChunk::addAnchorsAndShapes(iMesh* addTo) const
{
    std::ostringstream prefix;
    prefix << _id << ':';
    _chunk->addAnchorsAndShapes(addTo, _rotation, _scale, _x, _y, _z, prefix.str().c_str());
}

void demo(iPathEngine* pathEngine, iTestBed* testBed)
{
    iContentChunk* chunk1 = LoadChunk(pathEngine, testBed, "chunk1");
    iContentChunk* chunk2 = LoadChunk(pathEngine, testBed, "chunk2");
    iContentChunk* chunk3 = LoadChunk(pathEngine, testBed, "chunk3");
    iContentChunk* chunk4 = LoadChunk(pathEngine, testBed, "chunk4");

  // generate terrain stand-in geometry for the range -100000,-100000 -> 100000,100000
  // world coordinates are in millimetres, so this corresponds to a 200 metres by 200 metres region centred on the origin
    cPartitionedTerrain terrain(-100000, -100000, 20000, 10);

    std::vector<cPlacedContentChunk> placedChunks;

  // scaled and rotated instances of a two floor building around the origin

    placedChunks.push_back(cPlacedContentChunk(
            chunk1,
            0, // no rotation
            10, // no effective scale (since building scale = world scale / 10)
            0, 0, 0.f, // at origin
            placedChunks.size() // unique id for this placed object
            ));

    placedChunks.push_back(cPlacedContentChunk(
            chunk1,
            32, // 180 degree rotation - facing south
            11, // slightly larger than modelled
            0, 20000, 0.f, // 20 metres north of origin
            placedChunks.size()
            ));

    placedChunks.push_back(cPlacedContentChunk(
            chunk1,
            16, // 90 degree rotation - facing east
            20, // twice the size modelled
            -20000, 0, 0.f, // 20 metres west of origin
            placedChunks.size()
            ));

    placedChunks.push_back(cPlacedContentChunk(
            chunk1,
            48, // 270 degree rotation - facing west
            5, // half the size modelled
            20000, 0, 0.f, // 20 metres east of origin
            placedChunks.size()
            ));

  // some huts in a semi-circle on a hill to the south

    placedChunks.push_back(cPlacedContentChunk(chunk2,  0, 10, 0, -50000, 10000.f, placedChunks.size()));
    placedChunks.push_back(cPlacedContentChunk(chunk2,  4, 11, -6300, -49100, 9900.f, placedChunks.size()));
    placedChunks.push_back(cPlacedContentChunk(chunk2,  8, 12, -12500, -46000, 9800.f, placedChunks.size()));
    placedChunks.push_back(cPlacedContentChunk(chunk2, 12, 13, -15800, -41500, 9700.f, placedChunks.size()));

  // a bridge over the buildings near the origin

    placedChunks.push_back(cPlacedContentChunk(chunk3, 48, 50, 70000, 0, 0.f, placedChunks.size()));

  // a funny building with a big portal

    placedChunks.push_back(cPlacedContentChunk(chunk4, 32, 10, 0, 50000, 0.f, placedChunks.size()));

    std::vector<const iFaceVertexMesh*> groundParts;

    groundParts.push_back(&terrain);
    for(size_t i = 0; i < placedChunks.size(); ++i)
    {
        placedChunks[i].instantiate(groundParts);
    }

    // the following lines can be uncommented to write a file containing a snapshot of the data being passed into content processing
    // this can be imported into 3DS Max, and is useful for troubleshooting any problems with the content processing
//    {
//        cFileOutputStream fos("contentSnapshot.tok");
//        pathEngine->saveContentData(&groundParts.front(), groundParts.size(), "tok", &fos);
//    }

    iMesh* mesh = pathEngine->buildMeshFromContent(&groundParts.front(), groundParts.size(), 0);

    for(size_t i = 0; i < placedChunks.size(); ++i)
    {
        placedChunks[i].addAnchorsAndShapes(mesh);
    }

    testBed->setMesh(mesh);
    testBed->zoomExtents();

    while(!testBed->getKeyState("_SPACE"))
    {
        testBed->setColourRGB(0.0f,0.0f,0.85f);
        testBed->drawMesh();
        testBed->setColour("blue");
        testBed->drawMeshEdges();
        testBed->setColour("white");
        testBed->drawBurntInObstacles();
        testBed->printTextLine(10, "press space to quit..");
        testBed->printTextLine(10, "result of buildMeshFromContent()");
        testBed->update();
    }
}
