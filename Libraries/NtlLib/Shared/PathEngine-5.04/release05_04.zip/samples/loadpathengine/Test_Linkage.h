
class iPathEngine;
class iErrorHandler;
bool Test_Linkage(iPathEngine *pathengine, iErrorHandler *error_handler);
