
void ShowMessageBox(const char* title, const char* contents);
bool ShowMessageBoxQuery(const char* title, const char* contents, const char* query);
