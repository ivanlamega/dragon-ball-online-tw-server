
#include <vector>
void LoadBinary(const char* fileName, std::vector<char>& buffer);
