
class iPathEngine;
class iErrorHandler;
iPathEngine* LoadPathEngine(const char* filename, iErrorHandler *handler);
