
class cGameObject;
class iPath;

long GetPathFrequency(const cGameObject& controlledObject, const cGameObject& targetObject);
long GetPathFrequency(iPath* currentPath);
