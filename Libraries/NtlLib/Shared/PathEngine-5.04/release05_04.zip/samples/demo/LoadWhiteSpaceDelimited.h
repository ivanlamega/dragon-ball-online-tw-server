
#include <iosfwd>

class cSimpleDOM;
void LoadWhiteSpaceDelimited(std::istream& is, cSimpleDOM& result);
