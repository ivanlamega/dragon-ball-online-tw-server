//**********************************************************************
//
// Copyright (c) 2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#ifndef REPLACE_STL
#include <new>
#else
#ifndef NEW_INCLUDED
#define NEW_INCLUDED

//void* operator new(size_t);
//
//inline void*
//operator new(size_t, void* placementAddress)
//{
//    return placementAddress;
//}

#include <new>

#endif
#endif
