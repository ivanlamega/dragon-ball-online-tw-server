//**********************************************************************
//
// Copyright (c) 2006
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

class iXMLOutputStream;
class iAnchorsAndPinnedShapes;

void
SaveAnchorsAndPinnedShapes(
        const iAnchorsAndPinnedShapes& toSave,
        iXMLOutputStream& xos
        );
