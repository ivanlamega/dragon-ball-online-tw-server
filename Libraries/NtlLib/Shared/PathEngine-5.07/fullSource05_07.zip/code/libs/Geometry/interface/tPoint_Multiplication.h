
#include "libs/Geometry/interface/tPoint.h"
#include "platform_common/PointMultiplication.h"
