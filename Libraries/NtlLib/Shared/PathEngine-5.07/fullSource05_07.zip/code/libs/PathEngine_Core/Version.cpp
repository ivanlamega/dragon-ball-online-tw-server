
#include "interface/Version.h"

const
char* VersionTimeString()
{
    return "2007-01-05 10:12";
}
long
MajorRelease()
{
    return 5;
}
long
MinorRelease()
{
    return 7;
}
long
InternalRelease()
{
    return 0;
}

