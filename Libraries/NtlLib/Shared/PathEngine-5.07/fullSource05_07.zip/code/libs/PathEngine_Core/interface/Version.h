
const char* VersionTimeString();
long MajorRelease();
long MinorRelease();
long InternalRelease();
