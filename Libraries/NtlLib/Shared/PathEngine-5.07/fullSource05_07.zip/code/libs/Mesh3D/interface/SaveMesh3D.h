//**********************************************************************
//
// Copyright (c) 2005
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "libs/Mesh3D/interface/tMesh_3D_Header.h"

class iXMLOutputStream;

void SaveMesh3D(tMesh_3D& mesh, iXMLOutputStream& os);
