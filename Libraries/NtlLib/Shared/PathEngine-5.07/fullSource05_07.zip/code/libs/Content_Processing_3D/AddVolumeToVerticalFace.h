//**********************************************************************
//
// Copyright (c) 2006
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "tMesh_Simple3D_Header.h"

void
AddVolumeToVerticalFace(tMesh_Simple3D& mesh);
