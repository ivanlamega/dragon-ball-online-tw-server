//**********************************************************************
//
// Copyright (c) 2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "libs/Mesh2D/interface/tMesh_Header.h"

class iOutputStream;

void GenerateMeshCheckSum(const tMesh& mesh, iOutputStream& os);
