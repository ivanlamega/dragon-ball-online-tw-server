//**********************************************************************
//
// Copyright (c) 2002
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "libs/Mesh2D/interface/tMesh_Header.h"
#include "common/TemplateMesh/VectorMesh_Iterators.h"
//long GetFaceIndex(tFace f);
//long GetEdgeIndex(tEdge e);
