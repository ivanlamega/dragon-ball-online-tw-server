//**********************************************************************
//
// Copyright (c) 2002-2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

class controlinterface;
class osinterface;
void CameraControl(controlinterface* cip, osinterface* ip);
bool ShouldCameraTargetBeDisplayed();
