//**********************************************************************
//
// Copyright (c) 2004
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

class cSimpleDOM;

bool ParseToSimpleDOM(const char* format, const char* buffer, unsigned long bufferSize, cSimpleDOM& result);

