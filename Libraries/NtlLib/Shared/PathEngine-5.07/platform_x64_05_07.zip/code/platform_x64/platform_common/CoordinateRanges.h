//**********************************************************************
//
// Copyright (c) 2002-2005
// Thomas Young, PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#ifndef COORDINATERANGES_INCLUDED
#define COORDINATERANGES_INCLUDED

//const long WORLD_RANGE=131071;
const long WORLD_RANGE=1500000;
const long SHAPE_RANGE=8191;
const long DIRECTION_VECTOR_RANGE = 8191;

#endif
