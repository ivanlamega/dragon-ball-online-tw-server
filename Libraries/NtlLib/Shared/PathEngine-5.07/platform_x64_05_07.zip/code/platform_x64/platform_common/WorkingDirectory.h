//**********************************************************************
//
// Copyright (c) 2006
// PathEngine
// Lyon, France
//
// All Rights Reserved
//
//**********************************************************************

#include "common/STL/string.h"

inline std::string
WorkingDirectory()
{
    return "";
}

#define STATIC_STRING_FOR_FILE_IN_WORKING_DIRECTORY(fileName) fileName
